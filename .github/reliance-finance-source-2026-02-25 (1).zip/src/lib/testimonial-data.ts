import type { Testimonial } from './definitions';

export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Priya Sharma',
    location: 'Mumbai, Maharashtra',
    avatar: 'avatar-priya',
    originalQuote:
      "Getting a personal loan from Reliance Finance was an incredibly long and detailed process, but ultimately it was worth it. At first I was a bit overwhelmed with all the paperwork they needed, I mean Aadhaar, PAN, bank statements, photos, it felt like a lot. But their team was really patient and walked me through every single step. They called me multiple times to make sure I had everything right. The interest rate they offered was better than other places I checked. Now I've been able to consolidate my debts and my financial situation is so much more manageable. I'm really thankful for their help, even if it took a while to get there.",
    conciseQuote: "Reliance Finance helped me consolidate my debt with a great interest rate. The process was thorough, but their team's support made it manageable and worthwhile.",
    customerProfile: 'A 32-year-old marketing manager looking to consolidate credit card debt.',
    productOrService: 'Personal Loan',
    rating: 5,
  },
  {
    id: '2',
    name: 'Rohan Mehta',
    location: 'Delhi, NCR',
    avatar: 'avatar-rohan',
    originalQuote:
      "I needed a loan to expand my small business, and Reliance Finance came through for me. The application was straightforward, and I was ableto upload all my documents online which saved a ton of time. I really appreciated being able to track my application status with just my mobile number. It gave me peace of mind knowing where things stood. Within a week, the loan was approved and the funds were in my account. It was a seamless experience from start to finish.",
    customerProfile: 'A 45-year-old small business owner seeking funds for expansion.',
    productOrService: 'Small Business Loan',
    rating: 5,
  },
  {
    id: '3',
    name: 'Sunita Desai',
    location: 'Bengaluru, Karnataka',
    avatar: 'avatar-sunita',
    originalQuote:
      "As a freelancer, getting loans can be tough, but Reliance Finance understood my situation. They have a specific loan product for self-employed individuals which was perfect for me. My application was pending for a few days because I had forgotten to submit one document, but their system clearly stated the reason, and I was able to upload it right away. The transparency is what I loved most. Highly recommend them to other freelancers!",
    customerProfile: 'A 28-year-old freelance graphic designer needing a loan for new equipment.',
    productOrService: 'Loan for Self-Employed',
    rating: 5,
  },
  {
    id: '4',
    name: 'Vikram Singh',
    location: 'Jaipur, Rajasthan',
    avatar: 'avatar-vikram',
    originalQuote:
      "I was hesitant about online loan applications, but the experience with Reliance Finance was secure and professional. The approval letter was available to download with my mobile number, which felt very secure. Their customer service is top-notch. They are building a service that people can trust.",
    customerProfile: 'A 55-year-old teacher applying for a home renovation loan.',
    productOrService: 'Home Renovation Loan',
    rating: 4,
  },
];
