export type LoanApplication = {
  id: string;
  mobileNumber: string;
  email: string;
  name: string;
  loanAmount: number;
  gender: 'Male' | 'Female' | 'Other';
  state: string;
  loanPurpose: 'Personal Loan' | 'Business Loan' | 'Property/Home Loan' | 'Education Loan' | 'Other';
  status: 'Pending' | 'Approved' | 'Rejected' | 'Deleted';
  pendingReason?: string;
  createdAt: string;
  approvalLetterDataUri?: string;
  approvalLetterFilename?: string;
  pendingReasonImageUrl?: string;
  pendingReasonImageFilename?: string;
  paymentQrUrl?: string;
  paymentQrFilename?: string;
  paymentNote?: string;
  tenure?: number;
  emi?: number;
};

export type Testimonial = {
  id: string;
  name: string;
  location: string;
  avatar: string; // image id from placeholder-images.json
  originalQuote: string;
  customerProfile: string;
  productOrService: string;
  rating: number;
  conciseQuote?: string;
};

export type CompanyInfo = {
  contactNumber: string;
  address: string;
  pdfHeaderBlue?: string;
  pdfHeaderGreen?: string;
  pdfSlogan?: string;
  pdfNoticeText?: string;
  pdfProcessingFee?: string;
  pdfTerms?: string;
  pdfTitle?: string;
  pdfHeader1?: string;
  pdfHeader2?: string;
  pdfFooterSignatory?: string;
  pdfFooterTeam?: string;
  pdfSignatureDataUri?: string;
  pdfStampDataUri?: string;
  fontSizeHeader?: number;
  fontSizeTitle?: number;
  fontSizeBody?: number;
  fontSizeNote?: number;
  fontSizeFooter?: number;
};
