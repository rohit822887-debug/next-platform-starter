import { cache } from 'react';
import type { LoanApplication, CompanyInfo } from './definitions';
import fs from 'fs';
import path from 'path';

const dataFilePath = path.join(process.cwd(), 'src', 'lib', 'applications.json');
const companyInfoPath = path.join(process.cwd(), 'src', 'lib', 'company-info.json');

// Default info used if file doesn't exist
const defaultCompanyInfo: CompanyInfo = {
    contactNumber: '+91 95346 01575',
    address: '11th Floor, R-Tech IT Park,\nNirlon Compound Western Express Highway,\nGoregaon (East) Mumbai MH 400063',
    pdfHeaderBlue: '#0052cc',
    pdfHeaderGreen: '#508c00',
    pdfSlogan: 'Your trusted partner in financial services',
    pdfNoticeText: 'When you submit amount of File Processing Fee legal consideration charge fee INR 2,500/- After that it is our responsibility to hand over your approved loan value in your bank account in 5 minutes.',
    pdfProcessingFee: '2,500',
    pdfTerms: '1. We do not accept cash deposit.\n2. We accept only UPI/NEFT/IMPS/Mobile Banking and Other\n3. Processing fee will be refundable with loan amount.',
    pdfTitle: 'LOAN APPROVAL LETTER',
    pdfHeader1: 'RELIANCE',
    pdfHeader2: 'FINANCE LIMITED',
    pdfFooterSignatory: 'Er. Somayandu Ganguly',
    pdfFooterTeam: 'Divyesh B. Shah',
    fontSizeHeader: 24,
    fontSizeTitle: 16,
    fontSizeBody: 11,
    fontSizeNote: 10,
    fontSizeFooter: 11
};

// In-memory cache for applications
let applicationsCache: LoanApplication[] | null = null;
let companyInfoCache: CompanyInfo | null = null;

export const getApplications = cache((): LoanApplication[] => {
    if (applicationsCache) return applicationsCache;

    try {
        if(fs.existsSync(dataFilePath)) {
            const fileData = fs.readFileSync(dataFilePath, 'utf-8');
            if (fileData) {
                const data = JSON.parse(fileData);
                applicationsCache = data;
                return data;
            }
        }
    } catch (e) {
        console.error("Error reading applications data:", e);
    }
    return [];
});

export function saveApplications(applications: LoanApplication[]) {
    try {
        fs.writeFileSync(dataFilePath, JSON.stringify(applications, null, 2));
        applicationsCache = applications;
    } catch(e) {
        console.error("Error saving applications data:", e);
    }
}

export const getCompanyInfo = cache((): CompanyInfo => {
    if (companyInfoCache) return companyInfoCache;

    try {
        if(fs.existsSync(companyInfoPath)) {
            const fileData = fs.readFileSync(companyInfoPath, 'utf-8');
            if (fileData) {
                const data = JSON.parse(fileData);
                companyInfoCache = data;
                return data;
            }
        }
    } catch (e) {
        console.error("Error reading company info:", e);
    }

    return defaultCompanyInfo;
});

export function saveCompanyInfo(info: CompanyInfo) {
    try {
        fs.writeFileSync(companyInfoPath, JSON.stringify(info, null, 2));
        companyInfoCache = info;
    } catch(e) {
        console.error("Error saving company info:", e);
    }
}
