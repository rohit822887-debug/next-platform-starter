
'use server';

import { z } from 'zod';
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { 
  getApplications as getApplicationsFromDB, 
  saveApplications, 
  getCompanyInfo as getCompanyInfoFromDB, 
  saveCompanyInfo 
} from './data';
import type { LoanApplication, CompanyInfo } from './definitions';
import { revalidatePath } from 'next/cache';
import fs from 'fs';
import path from 'path';

const FormSchema = z.object({
  name: z.string().min(2, { message: 'Name must be at least 2 characters.' }),
  mobileNumber: z.string().regex(/^\d{10}$/, { message: 'Please enter a valid 10-digit mobile number.' }),
  email: z.string().email({ message: 'Please enter a valid email address.' }),
  loanAmount: z.coerce.number().min(1000, { message: 'Loan amount must be at least INR 1,000.' }),
  loanPurpose: z.enum(['Personal Loan', 'Business Loan', 'Property/Home Loan', 'Education Loan', 'Other']),
  gender: z.enum(['Male', 'Female', 'Other']),
  state: z.string().min(2, { message: 'Please select a state.' }),
});

export async function submitApplication(formData: FormData) {
  const validatedFields = FormSchema.safeParse({
    name: formData.get('name'),
    mobileNumber: formData.get('mobileNumber'),
    email: formData.get('email'),
    loanAmount: formData.get('loanAmount'),
    loanPurpose: formData.get('loanPurpose'),
    gender: formData.get('gender'),
    state: formData.get('state'),
  });

  if (!validatedFields.success) {
    return {
      success: false,
      errors: validatedFields.error.flatten().fieldErrors,
      message: 'Failed to submit application. Please check the fields.',
    };
  }
  
  const { name, mobileNumber, email, loanAmount, gender, state, loanPurpose } = validatedFields.data;
  
  const newApplication: LoanApplication = {
    id: `APP${String(Date.now()).slice(-6)}`,
    createdAt: new Date().toISOString(),
    name,
    mobileNumber,
    email,
    loanAmount,
    gender,
    state,
    loanPurpose,
    status: 'Pending',
  };

  const applications = getApplicationsFromDB();
  applications.unshift(newApplication);
  saveApplications(applications);

  return {
    success: true,
    redirectUrl: `/status?mobileNumber=${mobileNumber}&success=true`,
  };
}

export async function checkLoanStatus(mobileNumber: string) {
    const applications = getApplicationsFromDB();
    const application = applications.find(app => app.mobileNumber === mobileNumber);
    return application || null;
}

export async function getApplications() {
    const applications = getApplicationsFromDB();
    return applications.filter(app => app.status !== 'Deleted');
}

export async function getDeletedApplications() {
    const applications = getApplicationsFromDB();
    return applications.filter(app => app.status === 'Deleted');
}

export async function updateApplicationStatus(
  id: string,
  status: 'Pending' | 'Approved' | 'Rejected' | 'Deleted',
  reason: string,
  approvalLetterDataUri?: string,
  approvalLetterFilename?: string,
  pendingReasonImageDataUri?: string,
  pendingReasonImageFilename?: string,
  paymentQrDataUri?: string,
  paymentQrFilename?: string,
  paymentNote?: string,
  tenure?: number,
  emi?: number
) {
    const applications = getApplicationsFromDB();
    const applicationIndex = applications.findIndex(app => app.id === id);
    if (applicationIndex === -1) {
        return { success: false, message: 'Application not found.' };
    }

    const originalApplication = { ...applications[applicationIndex] };
    
    const updatedApplication: LoanApplication = {
        ...originalApplication,
        status,
        pendingReason: reason,
        tenure: tenure,
        emi: emi
    };

    if (status === 'Approved') {
        if (approvalLetterDataUri && approvalLetterFilename) {
            updatedApplication.approvalLetterDataUri = approvalLetterDataUri;
            updatedApplication.approvalLetterFilename = approvalLetterFilename;
        }
    } else {
        delete updatedApplication.approvalLetterDataUri;
        delete updatedApplication.approvalLetterFilename;
        delete updatedApplication.tenure;
        delete updatedApplication.emi;
    }

    if (status === 'Pending' && pendingReasonImageDataUri && pendingReasonImageFilename) {
        updatedApplication.pendingReasonImageUrl = pendingReasonImageDataUri;
        updatedApplication.pendingReasonImageFilename = pendingReasonImageFilename;
    } else if (status !== 'Pending') {
        delete updatedApplication.pendingReasonImageUrl;
        delete updatedApplication.pendingReasonImageFilename;
    }

    if (status === 'Pending' || status === 'Approved') {
        if (paymentQrDataUri && paymentQrFilename) {
            updatedApplication.paymentQrUrl = paymentQrDataUri;
            updatedApplication.paymentQrFilename = paymentQrFilename;
        }
        if (paymentNote) {
            updatedApplication.paymentNote = paymentNote;
        }
    } else {
        delete updatedApplication.paymentQrUrl;
        delete updatedApplication.paymentQrFilename;
        delete updatedApplication.paymentNote;
    }
    
    applications[applicationIndex] = updatedApplication;
    saveApplications(applications);
    
    return { success: true, application: updatedApplication };
}

export async function softDeleteApplication(id: string) {
    const applications = getApplicationsFromDB();
    const applicationIndex = applications.findIndex(app => app.id === id);
    if (applicationIndex === -1) {
        return { success: false, message: 'Application not found.' };
    }
    applications[applicationIndex].status = 'Deleted';
    saveApplications(applications);
    return { success: true, application: applications[applicationIndex] };
}

export async function recoverApplication(id: string) {
    const applications = getApplicationsFromDB();
    const applicationIndex = applications.findIndex(app => app.id === id);
    if (applicationIndex === -1) {
        return { success: false, message: 'Application not found.' };
    }
    applications[applicationIndex].status = 'Pending';
    saveApplications(applications);
    return { success: true, application: applications[applicationIndex] };
}

export async function bulkRecoverApplications(ids: string[]) {
    const applications = getApplicationsFromDB();
    let count = 0;
    applications.forEach(app => {
        if (ids.includes(app.id) && app.status === 'Deleted') {
            app.status = 'Pending';
            count++;
        }
    });
    if (count > 0) {
        saveApplications(applications);
    }
    return { success: true };
}

export async function permanentlyDeleteApplication(id: string) {
    let applications = getApplicationsFromDB();
    const applicationIndex = applications.findIndex(app => app.id === id);
    if (applicationIndex === -1) {
        return { success: false, message: 'Application not found.' };
    }

    if (applications[applicationIndex].status !== 'Deleted') {
        return { success: false, message: 'Application is not in the recycle bin.' };
    }

    applications.splice(applicationIndex, 1);
    saveApplications(applications);
    return { success: true };
}

export async function bulkPermanentlyDeleteApplications(ids: string[]) {
    let applications = getApplicationsFromDB();
    const newApplications = applications.filter(app => {
        if (ids.includes(app.id) && app.status === 'Deleted') {
            return false;
        }
        return true;
    });
    
    saveApplications(newApplications);
    return { success: true };
}

// --- Admin Auth ---
const ADMIN_PASSWORD = '7320'; 

export async function authenticateAdmin(prevState: any, formData: FormData) {
  const password = formData.get('password') as string;
  if (password === ADMIN_PASSWORD) {
    const cookieStore = await cookies();
    cookieStore.set('reliance-finance-auth', 'true', {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: 60 * 60 * 24, // 1 day
      path: '/',
    });
    redirect('/admin/dashboard');
  }
  return { message: 'Invalid password.' };
}

export async function logoutAdmin() {
  const cookieStore = await cookies();
  cookieStore.set('reliance-finance-auth', '', { expires: new Date(0) });
  redirect('/admin/login');
}

// --- Company Info ---
async function fileToDataUri(file: File): Promise<string | undefined> {
  if (!file || file.size === 0) return undefined;
  const bytes = await file.arrayBuffer();
  const buffer = Buffer.from(bytes);
  return `data:${file.type};base64,${buffer.toString('base64')}`;
}

export async function getCompanyInfo() {
  return getCompanyInfoFromDB();
}

export async function updateCompanyInfo(prevState: any, formData: FormData) {
    const currentInfo = getCompanyInfoFromDB();
    
    const contactNumber = formData.get('contactNumber') as string;
    const address = formData.get('address') as string;
    const pdfHeaderBlue = formData.get('pdfHeaderBlue') as string;
    const pdfHeaderGreen = formData.get('pdfHeaderGreen') as string;
    const pdfSlogan = formData.get('pdfSlogan') as string;
    const pdfNoticeText = formData.get('pdfNoticeText') as string;
    const pdfProcessingFee = formData.get('pdfProcessingFee') as string;
    const pdfTerms = formData.get('pdfTerms') as string;
    const pdfTitle = formData.get('pdfTitle') as string;
    const pdfHeader1 = formData.get('pdfHeader1') as string;
    const pdfHeader2 = formData.get('pdfHeader2') as string;
    const pdfFooterSignatory = formData.get('pdfFooterSignatory') as string;
    const pdfFooterTeam = formData.get('pdfFooterTeam') as string;

    const fontSizeHeader = Number(formData.get('fontSizeHeader')) || 24;
    const fontSizeTitle = Number(formData.get('fontSizeTitle')) || 16;
    const fontSizeBody = Number(formData.get('fontSizeBody')) || 11;
    const fontSizeNote = Number(formData.get('fontSizeNote')) || 10;
    const fontSizeFooter = Number(formData.get('fontSizeFooter')) || 11;

    if (!contactNumber || !address) {
        return {
          success: false,
          message: 'Contact number and address are required.',
        };
    }

    const signatureFile = formData.get('pdfSignature') as File;
    const signatureUri = await fileToDataUri(signatureFile);

    const stampFile = formData.get('pdfStamp') as File;
    const stampUri = await fileToDataUri(stampFile);

    const updatedInfo: CompanyInfo = {
        ...currentInfo,
        contactNumber,
        address,
        pdfHeaderBlue,
        pdfHeaderGreen,
        pdfSlogan,
        pdfNoticeText,
        pdfProcessingFee,
        pdfTerms,
        pdfTitle,
        pdfHeader1,
        pdfHeader2,
        pdfFooterSignatory,
        pdfFooterTeam,
        fontSizeHeader,
        fontSizeTitle,
        fontSizeBody,
        fontSizeNote,
        fontSizeFooter,
        pdfSignatureDataUri: signatureUri || currentInfo.pdfSignatureDataUri,
        pdfStampDataUri: stampUri || currentInfo.pdfStampDataUri
    };

    saveCompanyInfo(updatedInfo);

    revalidatePath('/admin/dashboard');
    revalidatePath('/status');
    revalidatePath('/');

    return {
        success: true,
    };
}

/**
 * Recursively gets all source files of the project for download.
 * Excludes node_modules, .next, and other build/dependency artifacts.
 */
export async function getProjectSource() {
  const files: { path: string; content: string }[] = [];
  const root = process.cwd();
  const includeDirs = ['src', 'docs', 'public'];
  const includeFiles = [
    'package.json',
    'next.config.ts',
    'tailwind.config.ts',
    'tsconfig.json',
    'apphosting.yaml',
    'README.md',
    'components.json'
  ];

  const walk = (dir: string) => {
    if (!fs.existsSync(dir)) return;
    const list = fs.readdirSync(dir);
    list.forEach(file => {
      const fullPath = path.join(dir, file);
      const stat = fs.statSync(fullPath);
      if (stat.isDirectory()) {
        if (file !== 'node_modules' && file !== '.next' && file !== '.git') {
          walk(fullPath);
        }
      } else {
        const relativePath = path.relative(root, fullPath);
        // We read the file as base64 so it can be safely sent over JSON
        const content = fs.readFileSync(fullPath).toString('base64');
        files.push({ path: relativePath, content });
      }
    });
  };

  includeDirs.forEach(dir => walk(path.join(root, dir)));
  includeFiles.forEach(file => {
    const fullPath = path.join(root, file);
    if (fs.existsSync(fullPath)) {
      const content = fs.readFileSync(fullPath).toString('base64');
      files.push({ path: file, content });
    }
  });

  return files;
}
