import { jsPDF } from 'jspdf';
import { format } from 'date-fns';
import type { LoanApplication, CompanyInfo } from './definitions';

export const generateApprovalPdf = (app: LoanApplication, config: CompanyInfo, tenureMonths: number, emi: number) => {
  try {
    const doc = new jsPDF();
    const today = format(new Date(app.createdAt || new Date()), 'dd-MMM-yyyy');

    const brandBlue = config.pdfHeaderBlue || '#0052cc';
    const principalColor = [91, 155, 213];
    const interestColor = [237, 125, 49];

    const fsHeader = config.fontSizeHeader || 24;
    const fsTitle = config.fontSizeTitle || 16;
    const fsBody = config.fontSizeBody || 11;
    const fsNote = config.fontSizeNote || 10;
    const fsFooter = config.fontSizeFooter || 11;

    const principal = Number(app.loanAmount || 0);
    const totalPayment = (emi || 0) * (tenureMonths || 0);
    const interestPayable = totalPayment - principal;

    const brandName = `${config.pdfHeader1 || ''} ${config.pdfHeader2 || ''}`.trim();

    // --- PAGE 1: OFFICIAL LETTER ---
    
    doc.setFontSize(fsHeader);
    doc.setTextColor(brandBlue);
    doc.setFont("helvetica", "bold");
    doc.text(String(config.pdfHeader1 || 'RELIANCE'), 20, 20);
    
    doc.setFontSize(fsHeader / 2);
    doc.setTextColor(100);
    doc.text(String(config.pdfHeader2 || 'FINANCE LIMITED'), 20, 28);

    doc.setDrawColor(brandBlue);
    doc.setLineWidth(1.5);
    doc.line(15, 35, 195, 35);

    doc.setFontSize(fsTitle);
    doc.setTextColor(brandBlue);
    const titleText = String(config.pdfTitle || 'LOAN APPROVAL LETTER');
    doc.text(titleText, 105, 45, { align: 'center' });
    const titleWidth = doc.getTextWidth(titleText);
    doc.setLineWidth(0.5);
    doc.line(105 - (titleWidth/2), 46, 105 + (titleWidth/2), 46);

    doc.setTextColor(0);
    doc.setFontSize(fsBody);
    doc.text("To,", 20, 55);
    const recipientName = `MR. ${String(app.name || '').toUpperCase()}`;
    doc.setFont("helvetica", "bold");
    doc.text(recipientName, 20, 62);
    doc.line(20, 63, 20 + doc.getTextWidth(recipientName), 63);

    doc.setFont("helvetica", "normal");
    doc.text(`•  Application No :- ${String(app.id || '')}`, 30, 70);
    doc.text(`•  Loan Purpose :- ${String(app.loanPurpose || '')}`, 30, 76);

    doc.text("Respected Sir/Ma'am,", 20, 88);
    const introText = `At the outset we welcome you to the world of "${brandName}". We are very glad to inform you that in response to your request for a loan in order to meet your financial needs.`;
    doc.text(doc.splitTextToSize(introText, 175), 20, 95);

    const amountStr = principal.toLocaleString('en-IN');
    const emiStr = (emi || 0).toLocaleString('en-IN');
    const loanPara = `You requested a short term loan, Sum of loan amount INR ${amountStr}/- for the tenure of ${tenureMonths} Month's on dated ${today}. Your monthly EMI is INR ${emiStr}/- at the rate of 7.2% including the rate of interest.`;
    doc.text(doc.splitTextToSize(loanPara, 175), 20, 115);

    const feePara = String(config.pdfNoticeText || '');
    doc.setTextColor(0);
    doc.text(doc.splitTextToSize(feePara, 175), 20, 135);
    doc.setFont("helvetica", "bold");
    doc.text(`Processing fee Legal Consideration INR ${config.pdfProcessingFee || '2,500'}/-`, 20, 155);

    doc.setTextColor(200, 0, 0);
    doc.text("Note:-", 20, 165);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(fsNote);
    const noteText = config.pdfTerms || "1. We do not accept cash deposit.\n2. We accept only UPI/NEFT/IMPS/Mobile Banking and Other\n3. Processing fee will be refundable with loan amount.";
    doc.text(noteText, 20, 172);

    const footerY = 270;
    
    // Mohar/Stamp (Bottom Left)
    if (config.pdfStampDataUri && config.pdfStampDataUri !== '') {
        try {
            doc.addImage(config.pdfStampDataUri, 20, footerY - 55, 60, 60);
        } catch (e) {
            console.error("PDF Stamp Error:", e);
        }
    }

    // Signatory (Bottom Right)
    const sigX = 145;
    doc.setTextColor(0);
    doc.setFontSize(fsFooter);
    doc.setFont("helvetica", "bold");
    doc.text(String(config.pdfFooterTeam || 'Reliance Finance Team'), sigX, footerY - 22);
    
    if (config.pdfSignatureDataUri && config.pdfSignatureDataUri !== '') {
        try {
            doc.addImage(config.pdfSignatureDataUri, sigX - 5, footerY - 20, 45, 15);
        } catch (e) {
            console.error("PDF Signature Error:", e);
        }
    }

    doc.setFontSize(fsFooter - 2);
    doc.setFont("helvetica", "normal");
    doc.text(String(config.pdfFooterSignatory || 'Authorized Signatory'), sigX, footerY);

    // --- PAGE 2: SUMMARY ---
    doc.addPage();
    
    doc.setFontSize(fsHeader - 4);
    doc.setTextColor(0);
    doc.setFont("helvetica", "bold");
    doc.text(`EMI : ${emiStr}.`, 105, 40, { align: 'center' });

    const barWidth = 120;
    const barHeight = 12;
    const startX = 45;
    const startY = 60;
    const pRatio = totalPayment > 0 ? (principal / totalPayment) : 1;
    const pWidth = barWidth * pRatio;
    const iWidth = barWidth - pWidth;

    doc.setFillColor(principalColor[0], principalColor[1], principalColor[2]);
    doc.rect(startX, startY, pWidth, barHeight, 'F');
    doc.setFillColor(interestColor[0], interestColor[1], interestColor[2]);
    doc.rect(startX + pWidth, startY, iWidth, barHeight, 'F');

    doc.setFontSize(fsNote);
    doc.setFont("helvetica", "normal");
    doc.setDrawColor(0);
    doc.setFillColor(interestColor[0], interestColor[1], interestColor[2]);
    doc.rect(20, 100, 5, 5, 'F');
    doc.rect(30, 97, 75, 10, 'S');
    doc.setTextColor(0);
    doc.text(`Interest Payable : ${interestPayable.toLocaleString('en-IN')}.`, 67.5, 103.5, { align: 'center' });

    doc.setFillColor(principalColor[0], principalColor[1], principalColor[2]);
    doc.rect(115, 100, 5, 5, 'F');
    doc.rect(125, 97, 75, 10, 'S');
    doc.text(`Principal Amount : ${principal.toLocaleString('en-IN')}.`, 162.5, 103.5, { align: 'center' });

    doc.rect(65, 115, 80, 10, 'S');
    doc.text(`Total Payment : ${totalPayment.toLocaleString('en-IN')}.`, 105, 121.5, { align: 'center' });

    doc.setFontSize(fsBody);
    const summaryClosingText = `Thank you for choosing "${brandName}" and we are assuring you for our best services time, Looking forward to a great and long relationship with us. For more details contact our executive.`;
    doc.text(doc.splitTextToSize(summaryClosingText, 175), 20, 150);

    doc.setFontSize(fsNote);
    doc.text("Address :-", 20, 180);
    const addrLines = (config.address || '').split('\n');
    addrLines.forEach((line, i) => {
        doc.text(line, 40, 180 + (i * 5));
    });
    
    return doc.output('datauristring');
  } catch (error) {
    console.error('PDF Error:', error);
    return null;
  }
};
