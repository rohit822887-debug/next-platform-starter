import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Testimonials from '@/components/testimonials';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Search, FileCheck } from 'lucide-react';
import dynamic from 'next/dynamic';
import { Skeleton } from '@/components/ui/skeleton';

const ApplicationForm = dynamic(() => import('@/components/application-form'), {
  loading: () => <div className="space-y-8 p-4"><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-full" /></div>,
});

const StatusChecker = dynamic(() => import('@/components/status-checker'), {
    loading: () => <div className="space-y-4 mb-8"><Skeleton className="h-10 w-full" /><Skeleton className="h-10 w-24" /></div>,
});

function Hero() {
  const heroImage = PlaceHolderImages.find(p => p.id === 'hero-background');
  return (
    <section className="relative h-[60vh] min-h-[400px] w-full flex items-center justify-center text-center text-white bg-primary/20">
      {heroImage && (
        <Image
          src={heroImage.imageUrl}
          alt={heroImage.description}
          fill
          sizes="100vw"
          className="object-cover z-0"
          data-ai-hint={heroImage.imageHint}
          priority
        />
      )}
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/30 to-transparent z-10"></div>
      <div className="relative z-20 flex flex-col items-center p-4">
        <h1 className="font-headline text-4xl md:text-6xl lg:text-7xl font-bold drop-shadow-lg">
          Financial Dreams, Realized.
        </h1>
        <p className="mt-4 max-w-3xl text-lg md:text-xl text-primary-foreground/90 drop-shadow-sm">
          Fast, transparent, and reliable loan services tailored for you, with interest rates starting from 7.2% per year. Check your status or apply today.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row gap-4">
          <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground">
            <Link href="/#apply-now">Apply for a Loan</Link>
          </Button>
          <Button asChild size="lg" variant="secondary">
            <Link href="#check-status">Check Status</Link>
          </Button>
        </div>
      </div>
    </section>
  );
}

function ApplicationSection() {
  return (
    <section id="apply-now" className="w-full scroll-mt-20 py-16 md:py-24">
      <div className="container">
        <div className="mx-auto max-w-4xl">
          <Card className="shadow-lg">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
                <FileCheck className="h-8 w-8" />
              </div>
              <CardTitle className="font-headline text-3xl md:text-4xl">Loan Application Form</CardTitle>
              <CardDescription className="text-lg">
                Fill in your details below to start your loan application process.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ApplicationForm />
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}

function StatusCheckSection() {
  return (
    <section id="check-status" className="w-full scroll-mt-20 py-16 md:py-24 bg-muted/40">
      <div className="container">
        <div className="mx-auto max-w-2xl">
        <Card className="shadow-lg">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Search className="h-8 w-8" />
            </div>
            <CardTitle className="font-headline text-3xl md:text-4xl">Check Your Loan Status</CardTitle>
            <CardDescription className="text-lg">
              Enter your mobile number to view the current status of your loan application.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <StatusChecker />
          </CardContent>
        </Card>
      </div>
      </div>
    </section>
  );
}


export default function Home() {
  return (
    <div className="flex flex-col">
      <Hero />
      <ApplicationSection />
      <StatusCheckSection />
      <Testimonials />
    </div>
  );
}
