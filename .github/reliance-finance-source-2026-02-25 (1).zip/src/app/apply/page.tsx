import { redirect } from 'next/navigation';

export default function ApplyPage() {
  redirect('/#apply-now');
  return null;
}
