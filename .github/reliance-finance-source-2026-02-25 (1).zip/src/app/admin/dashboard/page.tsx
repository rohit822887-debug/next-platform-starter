import ApplicationsTable from "@/components/admin/applications-table";
import CompanySettingsForm from "@/components/admin/company-settings-form";
import DeletedApplicationsTable from "@/components/admin/deleted-applications-table";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { getApplications, getCompanyInfo, getDeletedApplications } from "@/lib/actions";

export default async function AdminDashboardPage() {
  const applications = await getApplications();
  const deletedApplications = await getDeletedApplications();
  const companyInfo = await getCompanyInfo();

  return (
    <div className="space-y-6">
      <Tabs defaultValue="applications" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="applications">Applications</TabsTrigger>
          <TabsTrigger value="recycle_bin">Recycle Bin</TabsTrigger>
          <TabsTrigger value="settings">General & Template Settings</TabsTrigger>
        </TabsList>
        
        <TabsContent value="applications">
          <Card>
            <CardHeader>
              <CardTitle className="font-headline text-2xl">Loan Applications</CardTitle>
              <CardDescription>
                View, manage, and update all customer loan applications.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ApplicationsTable initialApplications={applications} companyInfo={companyInfo} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recycle_bin">
           <Card>
            <CardHeader>
              <CardTitle className="font-headline text-2xl">Recycle Bin</CardTitle>
              <CardDescription>
                Restore recently deleted applications.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <DeletedApplicationsTable initialApplications={deletedApplications} />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle className="font-headline text-2xl">Company & PDF Settings</CardTitle>
              <CardDescription>
                Customize your brand, contact details, and the look of the generated Approval Letters.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <CompanySettingsForm companyInfo={companyInfo} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
