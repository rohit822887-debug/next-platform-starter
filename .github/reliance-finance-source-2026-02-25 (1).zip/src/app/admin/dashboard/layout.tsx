import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import Logo from '@/components/logo';
import LogoutButton from '@/components/admin/logout-button';

export default async function AdminDashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const cookieStore = await cookies();
  const authCookie = cookieStore.get('reliance-finance-auth');

  if (authCookie?.value !== 'true') {
    redirect('/admin/login');
  }

  return (
    <div className="flex min-h-screen flex-col bg-muted/40">
      <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b bg-background px-4 sm:px-6">
        <Logo />
        <LogoutButton />
      </header>
      <main className="flex-1 p-4 sm:p-6">{children}</main>
    </div>
  );
}
