import StatusChecker from "@/components/status-checker";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Search } from "lucide-react";
import { getCompanyInfo } from "@/lib/actions";

export default async function StatusPage({
  searchParams,
}: {
  searchParams?: {
    mobileNumber?: string;
    success?: string;
  };
}) {
  const params = await searchParams;
  const mobileNumber = params?.mobileNumber || '';
  const isSuccess = params?.success === 'true';
  const companyInfo = await getCompanyInfo();

  return (
    <div className="container py-12 md:py-20">
      <div className="mx-auto max-w-2xl">
        <Card className="shadow-lg">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Search className="h-8 w-8" />
            </div>
            <CardTitle className="font-headline text-3xl md:text-4xl">Check Your Loan Status</CardTitle>
            <CardDescription className="text-lg">
              Enter your mobile number to view the current status of your loan application.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isSuccess && (
                <div className="mb-4 rounded-md border border-green-500 bg-green-50 p-4 text-center text-green-700">
                    <p className="font-bold">Application Submitted Successfully!</p>
                    <p className="text-sm">Your application is now being processed. You can check its status below.</p>
                </div>
            )}
            <StatusChecker initialMobileNumber={mobileNumber} initialCompanyInfo={companyInfo} />
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
