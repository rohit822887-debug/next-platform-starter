'use client';

import { useState, useTransition, useEffect, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { format } from 'date-fns';
import { AlertCircle, CheckCircle, Clock, Frown, Loader2, Download } from 'lucide-react';

import { checkLoanStatus, getCompanyInfo } from '@/lib/actions';
import type { LoanApplication, CompanyInfo } from '@/lib/definitions';
import { generateApprovalPdf } from '@/lib/pdf-utils';

import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from './ui/badge';

const formSchema = z.object({
  mobileNumber: z.string().regex(/^\d{10}$/, { message: 'Please enter a valid 10-digit mobile number.' }),
});

export default function StatusChecker({ initialMobileNumber, companyInfo: initialCompanyInfo }: { initialMobileNumber?: string, initialCompanyInfo?: CompanyInfo }) {
  const [application, setApplication] = useState<LoanApplication | null | undefined>(undefined);
  const [isPending, startTransition] = useTransition();
  const [companyInfo, setCompanyInfo] = useState<CompanyInfo | undefined>(initialCompanyInfo);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      mobileNumber: initialMobileNumber || '',
    },
  });

  const onSubmit = useCallback((values: z.infer<typeof formSchema>) => {
    startTransition(async () => {
      const result = await checkLoanStatus(values.mobileNumber);
      setApplication(result);
      if (result && !companyInfo) {
          const info = await getCompanyInfo();
          setCompanyInfo(info);
      }
    });
  }, [startTransition, companyInfo]);

  useEffect(() => {
    if (initialMobileNumber) {
      onSubmit({ mobileNumber: initialMobileNumber });
    }
  }, [initialMobileNumber, onSubmit]);

  const handleDownloadPdf = () => {
    if (!application || !companyInfo || !application.tenure) return;
    
    const uri = generateApprovalPdf(application, companyInfo, application.tenure, application.emi || 0);
    if (uri) {
        const link = document.createElement('a');
        link.href = uri;
        link.download = `Approval-Letter-${application.id}.pdf`;
        link.click();
    }
  };

  const StatusBadge = ({ status }: { status: LoanApplication['status'] }) => {
    const statusConfig = {
      Approved: {
        icon: <CheckCircle className="h-4 w-4" />,
        className: 'bg-green-100 text-green-800 border-green-200',
      },
      Pending: {
        icon: <Clock className="h-4 w-4" />,
        className: 'bg-yellow-100 text-yellow-800 border-yellow-200',
      },
      Rejected: {
        icon: <AlertCircle className="h-4 w-4" />,
        className: 'bg-red-100 text-red-800 border-red-200',
      },
    };
    const config = statusConfig[status as keyof typeof statusConfig];
    if (!config) return null;
    return (
      <Badge variant="outline" className={`gap-2 ${config.className}`}>
        {config.icon}
        {status}
      </Badge>
    );
  };

  return (
    <div>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="flex items-end gap-4 mb-8">
          <FormField
            control={form.control}
            name="mobileNumber"
            render={({ field }) => (
              <FormItem className="flex-grow">
                <FormLabel>Mobile Number</FormLabel>
                <FormControl>
                  <Input placeholder="Enter your 10-digit mobile number" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <Button type="submit" disabled={isPending}>
            {isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            Check Status
          </Button>
        </form>
      </Form>

      {application === undefined && !isPending ? null :
      isPending ? (
        <div className="flex justify-center items-center p-8">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      ) : application ? (
        <Card className="bg-background">
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-2xl font-semibold">
                    Status for {application.name}
                </CardTitle>
                <CardDescription>Application ID: {application.id}</CardDescription>
              </div>
              <StatusBadge status={application.status} />
            </div>
          </CardHeader>
          <CardContent className="space-y-6 pt-6 text-sm">
            <div className="grid grid-cols-[120px_1fr] items-center gap-x-4 gap-y-3">
                <div className="text-muted-foreground">Name</div>
                <div className="font-semibold text-foreground">{application.name}</div>

                <div className="text-muted-foreground">Email</div>
                <div className="font-semibold text-foreground">{application.email}</div>

                <div className="text-muted-foreground">Loan Amount</div>
                <div className="font-semibold text-foreground">INR {application.loanAmount.toLocaleString('en-IN')}</div>
                
                <div className="text-muted-foreground">Loan Purpose</div>
                <div className="font-semibold text-foreground">{application.loanPurpose}</div>

                <div className="text-muted-foreground">Submitted On</div>
                <div className="font-semibold text-foreground">{format(new Date(application.createdAt), 'dd MMMM, yyyy')}</div>
            </div>
            {application.status === 'Approved' && application.tenure && (
                <div className="mt-6 text-center border-t pt-6">
                    <p className="text-lg font-semibold text-green-700 mb-2">Congratulations! Your loan is approved.</p>
                    <p className="text-muted-foreground mb-4">You can download your official approval letter below.</p>
                    <Button onClick={handleDownloadPdf} size="lg">
                        <Download className="mr-2 h-4 w-4" />
                        Download Approval Letter
                    </Button>
                </div>
            )}
            {application.pendingReason && (
            <div className="rounded-md border p-4 bg-muted/50">
                <h4 className="font-semibold mb-1">Reason for current status:</h4>
                <p className="text-destructive">{application.pendingReason}</p>
            </div>
            )}
             {application.status === 'Pending' && application.pendingReasonImageUrl && (
                <div className="rounded-md border p-4">
                    <h4 className="font-semibold mb-2">Supporting Document</h4>
                    <div className="flex justify-center">
                        <img src={application.pendingReasonImageUrl} alt="Pending reason document" className="rounded-md border w-full h-auto" />
                    </div>
                    <div className="mt-4 text-center">
                        <Button asChild size="sm">
                            <a href={application.pendingReasonImageUrl} download={application.pendingReasonImageFilename || 'pending-document.jpg'}>
                                <Download className="mr-2 h-4 w-4" />
                                Download Image
                            </a>
                        </Button>
                    </div>
                </div>
            )}
            {(application.status === 'Pending' || application.status === 'Approved') && application.paymentQrUrl && (
              <div className="rounded-md border p-4">
                  <h4 className="font-semibold mb-2">Payment Information</h4>
                  <div className="flex justify-center">
                      <img src={application.paymentQrUrl} alt="Payment QR Code" className="rounded-md border w-full h-auto" />
                  </div>
                  {application.paymentNote && (
                      <p className="text-sm text-center text-green-700 mt-2">{application.paymentNote}</p>
                  )}
                  <div className="mt-4 text-center">
                      <Button asChild size="sm">
                          <a href={application.paymentQrUrl} download={application.paymentQrFilename || 'payment-qr.jpg'}>
                              <Download className="mr-2 h-4 w-4" />
                              Save QR in Gallery
                          </a>
                      </Button>
                  </div>
              </div>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="text-center text-muted-foreground p-8 border border-dashed rounded-lg">
            <Frown className="mx-auto h-12 w-12 mb-4" />
            <p className="font-bold">No Application Found</p>
            <p>We could not find an application associated with this mobile number.</p>
        </div>
      )}
    </div>
  );
}
