import { User, Star } from 'lucide-react';

import { testimonials as initialTestimonials } from '@/lib/testimonial-data';
import type { Testimonial } from '@/lib/definitions';
import { PlaceHolderImages } from '@/lib/placeholder-images';

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader } from '@/components/ui/card';

function TestimonialCard({ testimonial }: { testimonial: Testimonial }) {
  const avatar = PlaceHolderImages.find((p) => p.id === testimonial.avatar);

  return (
    <Card className="flex flex-col">
      <CardHeader className="flex flex-row items-center gap-4 pb-4">
        <Avatar className="h-12 w-12">
          {avatar ? (
             <AvatarImage
                src={avatar.imageUrl}
                alt={avatar.description}
                width={48}
                height={48}
                data-ai-hint={avatar.imageHint}
              />
          ) : null}
          <AvatarFallback>
            <User className="h-6 w-6" />
          </AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <p className="font-bold text-lg">{testimonial.name}</p>
          <p className="text-sm text-muted-foreground">{testimonial.location}</p>
        </div>
      </CardHeader>
      <CardContent className="flex-grow flex flex-col">
        <div className="flex items-center gap-0.5 mb-2">
            {Array.from({ length: 5 }, (_, i) => (
                <Star
                key={i}
                className={`w-5 h-5 ${
                    i < testimonial.rating
                    ? 'text-yellow-400 fill-yellow-400'
                    : 'text-muted-foreground/30 fill-muted-foreground/30'
                }`}
                />
            ))}
        </div>
        <p className="text-muted-foreground italic flex-grow">
          &ldquo;{testimonial.conciseQuote || testimonial.originalQuote}&rdquo;
        </p>
      </CardContent>
    </Card>
  );
}

export default function Testimonials() {
  return (
    <section className="w-full py-16 md:py-24 bg-background">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <Badge variant="outline" className="mb-4">
            Voices of Trust
          </Badge>
          <h2 className="font-headline text-3xl md:text-4xl font-bold">
            What Our Customers Say
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Real stories from people we've helped achieve their financial goals.
          </p>
        </div>
        <div className="mt-12 grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-2">
          {initialTestimonials.map((testimonial) => (
            <TestimonialCard 
              key={testimonial.id} 
              testimonial={testimonial} 
            />
          ))}
        </div>
      </div>
    </section>
  );
}
