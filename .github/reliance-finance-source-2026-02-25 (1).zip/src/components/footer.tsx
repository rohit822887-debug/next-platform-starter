import Logo from "./logo";
import { getCompanyInfo } from "@/lib/actions";
import { Phone } from "lucide-react";

export default async function Footer() {
  const companyInfo = await getCompanyInfo();
  const addressLines = companyInfo.address.split('\n');

  return (
    <footer className="border-t">
      <div className="container py-8 flex items-center justify-center">
        <div className="flex flex-col items-center gap-2 text-center">
            <Logo />
            <p className="text-sm text-muted-foreground">
                © {new Date().getFullYear()} Reliance Finance Limited. All rights reserved.
            </p>
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                <Phone className="h-4 w-4" />
                <a href={`tel:${companyInfo.contactNumber.replace(/\s/g, '')}`} className="hover:text-primary">{companyInfo.contactNumber}</a>
            </div>
            <address className="text-sm text-muted-foreground not-italic mt-2">
              Address :- {addressLines.map((line, index) => <span key={index}>{line}{index < addressLines.length - 1 && <br />}</span>)}
            </address>
        </div>
      </div>
    </footer>
  );
}
