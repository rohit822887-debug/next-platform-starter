'use client';

import { useActionState } from 'react';
import { useFormStatus } from 'react-dom';
import { authenticateAdmin } from '@/lib/actions';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Loader2, Lock } from 'lucide-react';

function LoginButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending} className="w-full">
      {pending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
      Log In
    </Button>
  );
}

export default function LoginForm() {
  const [state, formAction] = useActionState(authenticateAdmin, undefined);

  return (
    <form action={formAction} className="space-y-4">
      <div className="relative">
        <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <Input
          type="password"
          name="password"
          placeholder="Password"
          className="pl-10"
          required
        />
      </div>
      {state?.message && <p className="text-sm text-destructive">{state.message}</p>}
      <LoginButton />
    </form>
  );
}
