'use client';

import { useState, useTransition, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { format } from 'date-fns';
import * as XLSX from 'xlsx';
import { generateApprovalPdf } from '@/lib/pdf-utils';
import { updateApplicationStatus, softDeleteApplication } from '@/lib/actions';
import type { LoanApplication, CompanyInfo } from '@/lib/definitions';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { AlertCircle, CheckCircle, Clock, FileDown, MoreHorizontal, Loader2, View, Trash2, Download } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { useToast } from '@/hooks/use-toast';
import { Textarea } from '../ui/textarea';

export default function ApplicationsTable({ initialApplications, companyInfo }: { initialApplications: LoanApplication[], companyInfo: CompanyInfo }) {
  const [applications, setApplications] = useState<LoanApplication[]>(initialApplications);
  const [isPending, startTransition] = useTransition();
  const [updatingAppId, setUpdatingAppId] = useState<string | null>(null);
  const router = useRouter();

  const [selectedApp, setSelectedApp] = useState<LoanApplication | null>(null);
  const [isUpdateModalOpen, setUpdateModalOpen] = useState(false);
  const [isViewModalOpen, setViewModalOpen] = useState(false);
  const [newStatus, setNewStatus] = useState<LoanApplication['status'] | null>(null);
  const [reason, setReason] = useState('');
  const [paymentNote, setPaymentNote] = useState('');
  const [tenure, setTenure] = useState<string>('12');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [pendingReasonImageFile, setPendingReasonImageFile] = useState<File | null>(null);
  const [paymentQrImageFile, setPaymentQrImageFile] = useState<File | null>(null);
  const { toast } = useToast();

  const ANNUAL_INTEREST_RATE = 7.2;

  const calculatedEmi = useMemo(() => {
    if (!selectedApp || !tenure || isNaN(Number(tenure)) || Number(tenure) <= 0) return 0;
    const p = selectedApp.loanAmount;
    const r = ANNUAL_INTEREST_RATE / 12 / 100;
    const n = Number(tenure);
    const emi = (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    return Math.round(emi);
  }, [selectedApp, tenure]);

  const fileToDataUri = (file: File) => new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });

  const handleUpdate = (appId: string, status: 'Pending' | 'Approved' | 'Rejected', reason: string, approvalFile: File | null, pendingImage: File | null, paymentQr: File | null, note: string, generatedPdfUri?: string, tenureVal?: number, emiVal?: number) => {
    const originalApplications = [...applications];
    const appIndex = originalApplications.findIndex(a => a.id === appId);
    if (appIndex === -1) return;

    const tempFileData = generatedPdfUri 
        ? { approvalLetterFilename: `Approval-Letter-${appId}.pdf`, approvalLetterDataUri: generatedPdfUri } 
        : (approvalFile ? { approvalLetterFilename: approvalFile.name, approvalLetterDataUri: 'uploading...' } : {});
    
    const tempPendingImageData = pendingImage ? { pendingReasonImageFilename: pendingImage.name, pendingReasonImageUrl: 'uploading...' } : {};
    const tempQrData = paymentQr ? { paymentQrFilename: paymentQr.name, paymentQrUrl: 'uploading...'} : {};

    const updatedApp: LoanApplication = {
        ...originalApplications[appIndex],
        status: status,
        pendingReason: reason,
        paymentNote: note,
        ...tempFileData,
        ...tempPendingImageData,
        ...tempQrData,
        tenure: tenureVal,
        emi: emiVal
    };

    const newApplications = [...applications];
    newApplications[appIndex] = updatedApp;
    
    setApplications(newApplications);
    setUpdateModalOpen(false);
    setSelectedApp(null);
    setReason('');
    setPaymentNote('');
    setTenure('12');
    setSelectedFile(null);
    setPendingReasonImageFile(null);
    setPaymentQrImageFile(null);

    startTransition(async () => {
        setUpdatingAppId(appId);
        
        try {
          let approvalFileDataUri: string | undefined = generatedPdfUri;
          let approvalFileName: string | undefined = generatedPdfUri ? `Approval-Letter-${appId}.pdf` : undefined;

          if (status === 'Approved' && approvalFile && !generatedPdfUri) {
              approvalFileDataUri = await fileToDataUri(approvalFile);
              approvalFileName = approvalFile.name;
          }

          let pendingReasonImageDataUri: string | undefined;
          let pendingReasonImageFilename: string | undefined;

          if (status === 'Pending' && pendingImage) {
              pendingReasonImageDataUri = await fileToDataUri(pendingImage);
              pendingReasonImageFilename = pendingImage.name;
          }
          
          let paymentQrDataUri: string | undefined;
          let paymentQrFilename: string | undefined;

          if ((status === 'Pending' || status === 'Approved') && paymentQr) {
              paymentQrDataUri = await fileToDataUri(paymentQr);
              paymentQrFilename = paymentQr.name;
          }

          const result = await updateApplicationStatus(
            appId, 
            status, 
            reason, 
            approvalFileDataUri, 
            approvalFileName, 
            pendingReasonImageDataUri, 
            pendingReasonImageFilename, 
            paymentQrDataUri, 
            paymentQrFilename, 
            note,
            tenureVal,
            emiVal
          );
          if (result.success && result.application) {
              setApplications(prev => prev.map(app => (app.id === appId ? result.application! : app)));
              toast({ title: "Success", description: `Application status updated to ${status}.` });
          } else {
              setApplications(originalApplications);
              toast({
                  variant: "destructive",
                  title: "Update Failed",
                  description: result.message || "Could not update status. Reverting change.",
              });
          }
        } catch (error) {
          console.error('Update process error:', error);
          setApplications(originalApplications);
          toast({
            variant: "destructive",
            title: "Error",
            description: "An unexpected error occurred during update.",
          });
        } finally {
          setUpdatingAppId(null);
        }
    });
  };

  const handleDelete = (appId: string) => {
    const originalApplications = [...applications];
    setApplications(prev => prev.filter(app => app.id !== appId));

    startTransition(async () => {
        setUpdatingAppId(appId);
        const result = await softDeleteApplication(appId);
        if (result.success) {
            toast({ title: "Application Deleted", description: "The application has been moved to the recycle bin." });
            router.refresh();
        } else {
            setApplications(originalApplications);
            toast({
                variant: "destructive",
                title: "Delete Failed",
                description: result.message || "Could not delete application.",
            });
        }
        setUpdatingAppId(null);
    });
  };

  const openModalForUpdate = (app: LoanApplication, status: 'Pending' | 'Approved' | 'Rejected') => {
    setSelectedApp(app);
    setNewStatus(status);
    setReason(app.pendingReason || '');
    setPaymentNote(app.paymentNote || '');
    setTenure(app.tenure ? String(app.tenure) : '12');
    setSelectedFile(null);
    setPendingReasonImageFile(null);
    setPaymentQrImageFile(null);
    setUpdateModalOpen(true);
  };
  
  const handleModalSubmit = async () => {
    if (!selectedApp || !newStatus || newStatus === 'Deleted') return;
    
    let generatedPdfUri: string | undefined;
    const tenureNum = Number(tenure);
    const emiNum = calculatedEmi;

    if (newStatus === 'Approved') {
        generatedPdfUri = generateApprovalPdf(selectedApp, companyInfo, tenureNum, emiNum) || undefined;
        if (!generatedPdfUri) {
          toast({
            variant: "destructive",
            title: "Error",
            description: "Failed to generate approval PDF. Please try again.",
          });
          return;
        }
    }

    handleUpdate(selectedApp.id, newStatus, reason, selectedFile, pendingReasonImageFile, paymentQrImageFile, paymentNote, generatedPdfUri, tenureNum, emiNum);
  };

  const openViewModal = (app: LoanApplication) => {
    setSelectedApp(app);
    setViewModalOpen(true);
  };

  const StatusBadge = ({ status }: { status: LoanApplication['status'] }) => {
    const statusConfig = {
      Approved: 'bg-green-500',
      Pending: 'bg-yellow-500',
      Rejected: 'bg-red-500',
      Deleted: 'bg-gray-500',
    };
    return <Badge className={`${statusConfig[status]} text-white hover:${statusConfig[status]}`}>{status}</Badge>;
  };
  
  const handleExport = () => {
    const worksheetData = applications.map((app) => ({
      'Application ID': app.id,
      Name: app.name,
      'Mobile Number': app.mobileNumber,
      'Email': app.email,
      'Loan Amount': app.loanAmount,
      'Loan Purpose': app.loanPurpose,
      Gender: app.gender,
      State: app.state,
      Status: app.status,
      Reason: app.pendingReason || '',
      'Submitted At': format(new Date(app.createdAt), 'yyyy-MM-dd HH:mm:ss'),
    }));

    const worksheet = XLSX.utils.json_to_sheet(worksheetData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Applications');
    XLSX.writeFile(workbook, 'Reliance_Finance_Applications.xlsx');
  };

  return (
    <>
      <div className="flex justify-end mb-4">
        <Button onClick={handleExport} variant="outline">
            <FileDown className="mr-2 h-4 w-4" />
            Export to Excel
        </Button>
      </div>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Customer</TableHead>
              <TableHead className="hidden sm:table-cell">Loan Amount</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="hidden md:table-cell">Submitted</TableHead>
              <TableHead>
                <span className="sr-only">Actions</span>
              </TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {applications.map((app) => (
              <TableRow key={app.id} className={isPending && updatingAppId === app.id ? "opacity-50" : ""}>
                <TableCell>
                  <div className="font-medium">{app.name}</div>
                  <div className="text-sm text-muted-foreground">{app.mobileNumber}</div>
                </TableCell>
                <TableCell className="hidden sm:table-cell">
                  INR {app.loanAmount.toLocaleString('en-IN')}
                </TableCell>
                <TableCell>
                  <StatusBadge status={app.status} />
                </TableCell>
                <TableCell className="hidden md:table-cell">
                  {format(new Date(app.createdAt), 'dd MMM yyyy')}
                </TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button aria-haspopup="true" size="icon" variant="ghost" disabled={isPending && updatingAppId === app.id}>
                        {isPending && updatingAppId === app.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <MoreHorizontal className="h-4 w-4" />}
                        <span className="sr-only">Toggle menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuItem onSelect={() => openViewModal(app)}>
                        <View className="mr-2 h-4 w-4" /> View Details
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onSelect={() => openModalForUpdate(app, 'Approved')}>
                        <CheckCircle className="mr-2 h-4 w-4 text-green-500" /> Mark Approved
                      </DropdownMenuItem>
                      <DropdownMenuItem onSelect={() => openModalForUpdate(app, 'Pending')}>
                        <Clock className="mr-2 h-4 w-4 text-yellow-500" /> Mark Pending
                      </DropdownMenuItem>
                      <DropdownMenuItem onSelect={() => openModalForUpdate(app, 'Rejected')}>
                        <AlertCircle className="mr-2 h-4 w-4 text-red-500" /> Mark Rejected
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onSelect={() => handleDelete(app.id)} className="text-destructive focus:bg-destructive/10 focus:text-destructive">
                        <Trash2 className="mr-2 h-4 w-4" />
                        <span>Delete</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={isUpdateModalOpen} onOpenChange={setUpdateModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Update Application Status</DialogTitle>
            <DialogDescription>
              Update status for {selectedApp?.name}'s application.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="status" className="text-right">New Status</Label>
                <div className="col-span-3">{newStatus && <StatusBadge status={newStatus} />}</div>
            </div>
            {newStatus === 'Approved' && (
              <>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="tenure" className="text-right">
                    Tenure (Months)
                  </Label>
                  <Input
                    id="tenure"
                    type="number"
                    value={tenure}
                    onChange={(e) => setTenure(e.target.value)}
                    className="col-span-3"
                    placeholder="e.g. 12"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label className="text-right">Interest Rate</Label>
                  <div className="col-span-3 text-sm font-medium">{ANNUAL_INTEREST_RATE}% Yearly (Fixed)</div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label className="text-right">Estimated EMI</Label>
                  <div className="col-span-3 text-sm font-bold text-primary">INR {calculatedEmi.toLocaleString('en-IN')} / month</div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="payment-qr" className="text-right">
                    Payment QR
                  </Label>
                  <div className="col-span-3">
                    <Input
                      id="payment-qr"
                      type="file"
                      accept="image/*"
                      onChange={(e) => setPaymentQrImageFile(e.target.files ? e.target.files[0] : null)}
                      className="file:text-foreground"
                    />
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="payment-note" className="text-right">
                    QR Note
                  </Label>
                  <Textarea
                    id="payment-note"
                    value={paymentNote}
                    onChange={(e) => setPaymentNote(e.target.value)}
                    className="col-span-3"
                    placeholder="Note for the QR code..."
                  />
                </div>
                <div className="p-3 bg-blue-50 border border-blue-100 rounded-md text-xs text-blue-800">
                  <p className="font-bold mb-1">Notice:</p>
                  Approval letter will be generated based on the latest template.
                </div>
              </>
            )}
            {newStatus === 'Pending' && (
              <>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="pending-image" className="text-right">
                      Reason Image
                  </Label>
                  <div className="col-span-3">
                      <Input
                      id="pending-image"
                      type="file"
                      accept="image/*"
                      onChange={(e) => setPendingReasonImageFile(e.target.files ? e.target.files[0] : null)}
                      className="file:text-foreground"
                      />
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="payment-qr" className="text-right">
                        Payment QR
                    </Label>
                    <div className="col-span-3">
                        <Input
                        id="payment-qr"
                        type="file"
                        accept="image/*"
                        onChange={(e) => setPaymentQrImageFile(e.target.files ? e.target.files[0] : null)}
                        className="file:text-foreground"
                        />
                    </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="payment-note" className="text-right">
                        QR Note
                    </Label>
                    <Textarea
                        id="payment-note"
                        value={paymentNote}
                        onChange={(e) => setPaymentNote(e.target.value)}
                        className="col-span-3"
                        placeholder="Note for the QR code..."
                    />
                </div>
              </>
            )}
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="reason" className="text-right">
                Reason
              </Label>
              <Input
                id="reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="col-span-3"
                placeholder={`Reason for ${newStatus?.toLowerCase()} status...`}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setUpdateModalOpen(false)}>Cancel</Button>
            <Button onClick={handleModalSubmit} disabled={isPending}>
                {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {newStatus === 'Approved' ? 'Approve & Save' : 'Update Status'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={isViewModalOpen} onOpenChange={setViewModalOpen}>
        <DialogContent className="sm:max-w-2xl">
            <DialogHeader>
                <DialogTitle>Application Details</DialogTitle>
                <DialogDescription>
                    Full details for application ID: {selectedApp?.id}
                </DialogDescription>
            </DialogHeader>
            {selectedApp && (
                <div className="grid gap-4 py-4 text-sm">
                    <div className="grid grid-cols-[100px_1fr] items-center gap-x-4 gap-y-2">
                        <div className="text-muted-foreground">Name:</div>
                        <div className="font-medium">{selectedApp.name}</div>
                        
                        <div className="text-muted-foreground">Mobile:</div>
                        <div className="font-medium">{selectedApp.mobileNumber}</div>
                        
                        <div className="text-muted-foreground">Email:</div>
                        <div className="font-medium">{selectedApp.email}</div>

                        <div className="text-muted-foreground">Loan Amount:</div>
                        <div className="font-medium">INR {selectedApp.loanAmount.toLocaleString('en-IN')}</div>
                        
                        <div className="text-muted-foreground">Purpose:</div>
                        <div className="font-medium">{selectedApp.loanPurpose}</div>

                        <div className="text-muted-foreground">Gender:</div>
                        <div className="font-medium">{selectedApp.gender}</div>

                        <div className="text-muted-foreground">State:</div>
                        <div className="font-medium">{selectedApp.state}</div>

                        <div className="text-muted-foreground">Status:</div>
                        <div><StatusBadge status={selectedApp.status} /></div>

                        <div className="text-muted-foreground">Submitted:</div>
                        <div className="font-medium">{format(new Date(selectedApp.createdAt), 'dd MMM yyyy, HH:mm')}</div>
                    </div>

                    {(selectedApp.pendingReason || selectedApp.pendingReasonImageUrl || selectedApp.tenure || selectedApp.paymentQrUrl) && (
                      <div className="space-y-4 pt-4 border-t">
                        {selectedApp.pendingReason && (
                            <div>
                                <div className="text-muted-foreground font-semibold">Reason for Status:</div>
                                <div className="font-medium mt-1 border bg-muted/50 p-3 rounded-md text-red-600">{selectedApp.pendingReason}</div>
                            </div>
                        )}
                        {selectedApp.pendingReasonImageUrl && (
                            <div>
                                <div className="text-muted-foreground font-semibold">Supporting Document:</div>
                                <div className="mt-2">
                                    <img src={selectedApp.pendingReasonImageUrl} alt="Pending reason" className="rounded-md border w-full h-auto" />
                                    <Button asChild variant="link" className="p-0 h-auto mt-2 text-sm">
                                        <a href={selectedApp.pendingReasonImageUrl} download={selectedApp.pendingReasonImageFilename}>
                                          <Download className="mr-2 h-3 w-3"/>
                                          Download Document
                                        </a>
                                    </Button>
                                </div>
                            </div>
                        )}
                        {selectedApp.paymentQrUrl && (
                            <div>
                                <div className="text-muted-foreground font-semibold">Payment QR Code:</div>
                                <div className="mt-2">
                                    <img src={selectedApp.paymentQrUrl} alt="Payment QR Code" className="rounded-md border w-full h-auto" />
                                    <Button asChild variant="link" className="p-0 h-auto mt-2 text-sm">
                                        <a href={selectedApp.paymentQrUrl} download={selectedApp.paymentQrFilename || 'payment-qr.jpg'}>
                                          <Download className="mr-2 h-3 w-3"/>
                                          Download QR
                                        </a>
                                    </Button>
                                </div>
                            </div>
                        )}
                        {selectedApp.paymentNote && (
                            <div>
                                <div className="text-muted-foreground font-semibold">Note:</div>
                                <div className="font-medium mt-1 border bg-muted/50 p-3 rounded-md text-green-700">{selectedApp.paymentNote}</div>
                            </div>
                        )}
                         {selectedApp.status === 'Approved' && selectedApp.tenure && (
                            <div>
                              <div className="text-muted-foreground font-semibold">Approval Actions</div>
                              <div className="flex gap-2 mt-2">
                                <Button size="sm" onClick={() => {
                                    const uri = generateApprovalPdf(selectedApp, companyInfo, selectedApp.tenure!, selectedApp.emi || 0);
                                    if (uri) {
                                        const link = document.createElement('a');
                                        link.href = uri;
                                        link.download = `Approval-Letter-${selectedApp.id}.pdf`;
                                        link.click();
                                    }
                                }}>
                                    <Download className="mr-2 h-4 w-4"/>
                                    Download Latest Letter
                                </Button>
                              </div>
                            </div>
                        )}
                      </div>
                    )}
                </div>
            )}
            <DialogFooter className="sm:justify-start">
                <Button type="button" variant="outline" onClick={() => setViewModalOpen(false)}>Close</Button>
            </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
