
'use client';

import { useEffect, useActionState, useState } from 'react';
import { useFormStatus } from 'react-dom';
import { updateCompanyInfo, getProjectSource } from '@/lib/actions';
import { Button } from '../ui/button';
import { Input } from '../ui/input';
import { Label } from '../ui/label';
import { Loader2, Type, BadgeIndianRupee, Download, Package } from 'lucide-react';
import type { CompanyInfo } from '@/lib/definitions';
import { useToast } from '@/hooks/use-toast';
import { Textarea } from '../ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '../ui/card';
import JSZip from 'jszip';

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending} className="w-full">
      {pending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : 'Save All Settings'}
    </Button>
  );
}

export default function CompanySettingsForm({ companyInfo }: { companyInfo: CompanyInfo }) {
  const [state, formAction] = useActionState(updateCompanyInfo, undefined);
  const { toast } = useToast();
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    if (state === undefined) return;
    if (state.success) {
        toast({ title: "Success", description: "Settings updated successfully." });
    } else if (state.message) {
        toast({ variant: "destructive", title: "Error", description: state.message });
    }
  }, [state, toast]);

  const handleExportSource = async () => {
    setIsExporting(true);
    try {
      const files = await getProjectSource();
      const zip = new JSZip();
      
      files.forEach(f => {
        zip.file(f.path, f.content, { base64: true });
      });

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `reliance-finance-source-${new Date().toISOString().split('T')[0]}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);

      toast({ title: "Export Complete", description: "Your source code ZIP has been downloaded." });
    } catch (error) {
      console.error("Export Error:", error);
      toast({ variant: "destructive", title: "Export Failed", description: "Could not bundle the source code. Please try again." });
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-8">
      <form action={formAction} className="space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Basic Info */}
          <Card>
            <CardHeader>
              <CardTitle>Basic Information</CardTitle>
              <CardDescription>Main contact details for the website.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="contactNumber">Contact Number</Label>
                <Input
                  id="contactNumber"
                  name="contactNumber"
                  defaultValue={companyInfo.contactNumber}
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="address">Address</Label>
                <Textarea
                  id="address"
                  name="address"
                  defaultValue={companyInfo.address}
                  required
                  rows={3}
                />
              </div>
            </CardContent>
          </Card>

          {/* Signature & Stamp Upload */}
          <Card>
            <CardHeader>
              <CardTitle>Signature & Assets</CardTitle>
              <CardDescription>Upload image assets for the PDF.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="pdfSignature">Authorized Signatory Picture</Label>
                <div className="flex items-center gap-4">
                  {companyInfo.pdfSignatureDataUri && (
                    <img src={companyInfo.pdfSignatureDataUri} alt="Signature Preview" className="h-10 w-20 object-contain border rounded p-1" />
                  )}
                  <Input
                    id="pdfSignature"
                    name="pdfSignature"
                    type="file"
                    accept="image/*"
                    className="file:bg-primary file:text-primary-foreground file:border-0 file:rounded-md file:px-2"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="pdfStamp">Company Stamp (Mohar)</Label>
                <div className="flex items-center gap-4">
                  {companyInfo.pdfStampDataUri && (
                    <img src={companyInfo.pdfStampDataUri} alt="Stamp Preview" className="h-20 w-20 object-contain border rounded p-1" />
                  )}
                  <Input
                    id="pdfStamp"
                    name="pdfStamp"
                    type="file"
                    accept="image/*"
                    className="file:bg-primary file:text-primary-foreground file:border-0 file:rounded-md file:px-2"
                  />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* PDF Template Style */}
          <Card>
            <CardHeader>
              <CardTitle>PDF Template Style</CardTitle>
              <CardDescription>Customize colors and header structure.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="pdfHeaderBlue">Primary Brand Color</Label>
                  <div className="flex gap-2">
                    <Input type="color" className="w-12 p-1 h-10" name="pdfHeaderBlue" defaultValue={companyInfo.pdfHeaderBlue || '#0052cc'} />
                    <Input name="pdfHeaderBlue" defaultValue={companyInfo.pdfHeaderBlue || '#0052cc'} className="flex-1" />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pdfHeaderGreen">Secondary Brand Color</Label>
                  <div className="flex gap-2">
                    <Input type="color" className="w-12 p-1 h-10" name="pdfHeaderGreen" defaultValue={companyInfo.pdfHeaderGreen || '#508c00'} />
                    <Input name="pdfHeaderGreen" defaultValue={companyInfo.pdfHeaderGreen || '#508c00'} className="flex-1" />
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="pdfHeader1">Main Header Text (Line 1)</Label>
                <Input id="pdfHeader1" name="pdfHeader1" defaultValue={companyInfo.pdfHeader1 || 'RELIANCE'} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pdfHeader2">Main Header Text (Line 2)</Label>
                <Input id="pdfHeader2" name="pdfHeader2" defaultValue={companyInfo.pdfHeader2 || 'FINANCE LIMITED'} />
              </div>
            </CardContent>
          </Card>

          {/* Font Sizes */}
          <Card>
            <CardHeader>
              <CardTitle>Font & Typography</CardTitle>
              <CardDescription>Control the text sizes in the PDF.</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fontSizeHeader" className="flex items-center gap-2">
                  <Type className="h-4 w-4" /> Header Size
                </Label>
                <Input type="number" id="fontSizeHeader" name="fontSizeHeader" defaultValue={companyInfo.fontSizeHeader || 24} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fontSizeTitle" className="flex items-center gap-2">
                  <Type className="h-4 w-4" /> Title Size
                </Label>
                <Input type="number" id="fontSizeTitle" name="fontSizeTitle" defaultValue={companyInfo.fontSizeTitle || 16} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fontSizeBody" className="flex items-center gap-2">
                  <Type className="h-4 w-4" /> Body Size
                </Label>
                <Input type="number" id="fontSizeBody" name="fontSizeBody" defaultValue={companyInfo.fontSizeBody || 11} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fontSizeNote" className="flex items-center gap-2">
                  <Type className="h-4 w-4" /> Note/Terms Size
                </Label>
                <Input type="number" id="fontSizeNote" name="fontSizeNote" defaultValue={companyInfo.fontSizeNote || 10} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fontSizeFooter" className="flex items-center gap-2">
                  <Type className="h-4 w-4" /> Footer Size
                </Label>
                <Input type="number" id="fontSizeFooter" name="fontSizeFooter" defaultValue={companyInfo.fontSizeFooter || 11} />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* PDF Body Content */}
          <Card>
            <CardHeader>
              <CardTitle>PDF Main Content</CardTitle>
              <CardDescription>Edit the core text blocks of the letter.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="pdfTitle">Document Title</Label>
                <Input id="pdfTitle" name="pdfTitle" defaultValue={companyInfo.pdfTitle || 'LOAN APPROVAL LETTER'} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pdfSlogan">PDF Slogan</Label>
                <Input
                  id="pdfSlogan"
                  name="pdfSlogan"
                  defaultValue={companyInfo.pdfSlogan}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pdfProcessingFee" className="flex items-center gap-2">
                  <BadgeIndianRupee className="h-4 w-4" /> Processing Fee (Amount only)
                </Label>
                <Input
                  id="pdfProcessingFee"
                  name="pdfProcessingFee"
                  placeholder="e.g. 2,500"
                  defaultValue={companyInfo.pdfProcessingFee || ''}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pdfNoticeText">Important Notice Text</Label>
                <Textarea
                  id="pdfNoticeText"
                  name="pdfNoticeText"
                  defaultValue={companyInfo.pdfNoticeText}
                  rows={4}
                />
              </div>
            </CardContent>
          </Card>

          {/* Terms & Signature */}
          <Card>
            <CardHeader>
              <CardTitle>Terms & Signature</CardTitle>
              <CardDescription>Final sections of the approval document.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="pdfTerms">Terms and Conditions (One per line)</Label>
                <Textarea
                  id="pdfTerms"
                  name="pdfTerms"
                  defaultValue={companyInfo.pdfTerms}
                  rows={5}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="pdfFooterSignatory">Signatory Name</Label>
                  <Input id="pdfFooterSignatory" name="pdfFooterSignatory" defaultValue={companyInfo.pdfFooterSignatory || 'Jai Anmol Ambani'} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pdfFooterTeam">Signatory Title/Team</Label>
                  <Input id="pdfFooterTeam" name="pdfFooterTeam" defaultValue={companyInfo.pdfFooterTeam || 'Reliance Finance Team'} />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {state?.message && !state.success && <p className="text-sm text-destructive">{state.message}</p>}
        <SubmitButton />
      </form>

      {/* Backup Section */}
      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Package className="h-5 w-5 text-primary" />
            Backup & Export
          </CardTitle>
          <CardDescription>
            Download the complete website source code (including this portal) as a ZIP file. 
            Useful for moving the project or keeping a local backup.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button 
            variant="outline" 
            className="w-full sm:w-auto" 
            onClick={handleExportSource}
            disabled={isExporting}
          >
            {isExporting ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Download className="mr-2 h-4 w-4" />
            )}
            Download Full Source Code (.ZIP)
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
