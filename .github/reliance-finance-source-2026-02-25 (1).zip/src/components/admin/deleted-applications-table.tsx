'use client';

import { useState, useTransition } from 'react';
import { useRouter } from 'next/navigation';
import { format } from 'date-fns';
import { 
  recoverApplication, 
  permanentlyDeleteApplication, 
  bulkPermanentlyDeleteApplications, 
  bulkRecoverApplications 
} from '@/lib/actions';
import type { LoanApplication } from '@/lib/definitions';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2, MoreHorizontal, RotateCcw, Trash2, Trash } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function DeletedApplicationsTable({ initialApplications }: { initialApplications: LoanApplication[] }) {
  const [applications, setApplications] = useState<LoanApplication[]>(initialApplications);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [isPending, startTransition] = useTransition();
  const [activeAppId, setActiveAppId] = useState<string | null>(null);
  const [appToDelete, setAppToDelete] = useState<LoanApplication | null>(null);
  const [isBulkDeleteAlertOpen, setIsBulkDeleteAlertOpen] = useState(false);
  const [isEmptyArchiveAlertOpen, setIsEmptyArchiveAlertOpen] = useState(false);
  
  const router = useRouter();
  const { toast } = useToast();

  const toggleSelectAll = () => {
    if (selectedIds.length === applications.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(applications.map(app => app.id));
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleRecover = (appId: string) => {
    const originalApplications = [...applications];
    setApplications(prev => prev.filter(app => app.id !== appId));
    setSelectedIds(prev => prev.filter(id => id !== appId));

    startTransition(async () => {
        setActiveAppId(appId);
        const result = await recoverApplication(appId);
        if (result.success) {
            toast({ title: "Application Recovered", description: "The application has been restored." });
            router.refresh(); 
        } else {
            setApplications(originalApplications);
            toast({
                variant: "destructive",
                title: "Recovery Failed",
                description: result.message || "Could not recover application.",
            });
        }
        setActiveAppId(null);
    });
  };

  const handleBulkRecover = () => {
    if (selectedIds.length === 0) return;
    const idsToRecover = [...selectedIds];
    const originalApplications = [...applications];
    
    setApplications(prev => prev.filter(app => !idsToRecover.includes(app.id)));
    setSelectedIds([]);

    startTransition(async () => {
        const result = await bulkRecoverApplications(idsToRecover);
        if (result.success) {
            toast({ title: "Applications Recovered", description: `${idsToRecover.length} applications restored.` });
            router.refresh();
        } else {
            setApplications(originalApplications);
            toast({ variant: "destructive", title: "Error", description: "Recovery failed." });
        }
    });
  };

  const handlePermanentDelete = (appId: string) => {
    const originalApplications = [...applications];
    setApplications(prev => prev.filter(app => app.id !== appId));
    setSelectedIds(prev => prev.filter(id => id !== appId));
    setAppToDelete(null);

    startTransition(async () => {
        setActiveAppId(appId);
        const result = await permanentlyDeleteApplication(appId);
        if (result.success) {
            toast({ title: "Deleted", description: "Permanent removal successful." });
        } else {
            setApplications(originalApplications);
            toast({ variant: "destructive", title: "Error", description: "Delete failed." });
        }
        setActiveAppId(null);
    });
  };

  const handleBulkDelete = () => {
    if (selectedIds.length === 0) return;
    const idsToDelete = [...selectedIds];
    const originalApplications = [...applications];
    
    setApplications(prev => prev.filter(app => !idsToDelete.includes(app.id)));
    setSelectedIds([]);
    setIsBulkDeleteAlertOpen(false);

    startTransition(async () => {
        const result = await bulkPermanentlyDeleteApplications(idsToDelete);
        if (result.success) {
            toast({ title: "Deleted", description: `${idsToDelete.length} items removed.` });
        } else {
            setApplications(originalApplications);
            toast({ variant: "destructive", title: "Error", description: "Bulk delete failed." });
        }
    });
  };

  const handleEmptyArchive = () => {
    const idsToDelete = applications.map(app => app.id);
    const originalApplications = [...applications];
    
    setApplications([]);
    setSelectedIds([]);
    setIsEmptyArchiveAlertOpen(false);

    startTransition(async () => {
        const result = await bulkPermanentlyDeleteApplications(idsToDelete);
        if (result.success) {
            toast({ title: "Archive Emptied", description: "All archived items removed." });
        } else {
            setApplications(originalApplications);
            toast({ variant: "destructive", title: "Error", description: "Failed to empty archive." });
        }
    });
  };

  return (
    <>
      <div className="flex flex-wrap gap-2 mb-4 justify-between items-center">
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={handleBulkRecover} disabled={selectedIds.length === 0 || isPending}>
            <RotateCcw className="mr-2 h-4 w-4" />
            Restore ({selectedIds.length})
          </Button>
          <Button variant="destructive" size="sm" onClick={() => setIsBulkDeleteAlertOpen(true)} disabled={selectedIds.length === 0 || isPending}>
            <Trash2 className="mr-2 h-4 w-4" />
            Delete ({selectedIds.length})
          </Button>
        </div>
        <Button variant="ghost" size="sm" onClick={() => setIsEmptyArchiveAlertOpen(true)} disabled={applications.length === 0 || isPending} className="text-muted-foreground hover:text-destructive">
          <Trash className="mr-2 h-4 w-4" />
          Empty Recycle Bin
        </Button>
      </div>

      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[50px]">
                <Checkbox checked={applications.length > 0 && selectedIds.length === applications.length} onCheckedChange={toggleSelectAll} />
              </TableHead>
              <TableHead>Customer</TableHead>
              <TableHead className="hidden sm:table-cell">Loan Amount</TableHead>
              <TableHead className="hidden md:table-cell">Submitted</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {applications.length === 0 ? (
              <TableRow>
                <TableCell colSpan={5} className="h-24 text-center text-muted-foreground">Archive is empty.</TableCell>
              </TableRow>
            ) : (
              applications.map((app) => (
                <TableRow key={app.id} className={isPending && activeAppId === app.id ? "opacity-50" : ""}>
                  <TableCell>
                    <Checkbox checked={selectedIds.includes(app.id)} onCheckedChange={() => toggleSelect(app.id)} />
                  </TableCell>
                  <TableCell>
                    <div className="font-medium">{app.name}</div>
                    <div className="text-sm text-muted-foreground">{app.mobileNumber}</div>
                  </TableCell>
                  <TableCell className="hidden sm:table-cell">INR {app.loanAmount.toLocaleString('en-IN')}</TableCell>
                  <TableCell className="hidden md:table-cell">{format(new Date(app.createdAt), 'dd MMM yyyy')}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" disabled={isPending && activeAppId === app.id}>
                          {isPending && activeAppId === app.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <MoreHorizontal className="h-4 w-4" />}
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onSelect={() => handleRecover(app.id)}>
                          <RotateCcw className="mr-2 h-4 w-4" /> Restore
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onSelect={() => setAppToDelete(app)} className="text-destructive focus:bg-destructive/10">
                          <Trash2 className="mr-2 h-4 w-4" /> Permanent Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      <AlertDialog open={!!appToDelete} onOpenChange={(open) => !open && setAppToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Permanent Deletion</AlertDialogTitle>
            <AlertDialogDescription>Permanently remove application for {appToDelete?.name}?</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => appToDelete && handlePermanentDelete(appToDelete.id)} className="bg-destructive hover:bg-destructive/90">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={isBulkDeleteAlertOpen} onOpenChange={setIsBulkDeleteAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Bulk Permanent Deletion</AlertDialogTitle>
            <AlertDialogDescription>Remove {selectedIds.length} items forever?</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleBulkDelete} className="bg-destructive hover:bg-destructive/90">Delete All Selected</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={isEmptyArchiveAlertOpen} onOpenChange={setIsEmptyArchiveAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Empty Entire Recycle Bin?</AlertDialogTitle>
            <AlertDialogDescription>This will permanently remove EVERY archived application.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleEmptyArchive} className="bg-destructive hover:bg-destructive/90">Empty Bin</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
