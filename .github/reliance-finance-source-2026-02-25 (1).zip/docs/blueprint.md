# **App Name**: Reliance Finance Portal

## Core Features:

- Loan Status Check: Customers can check their loan application status (approved, pending, reason for pending) using their mobile number.
- Admin Approval Letter Upload: Admin users can upload approval letters (PDFs).
- Approval Letter Access: Customers can access their approval letter using their mobile number to verify their identity.
- Admin Status Update: Admin users can update the status of loan applications (approved/pending) and specify reasons for pending applications.
- Customer Details Check: Customers can view all their application details using their mobile number.
- Testimonial Showcase: Display positive testimonials from Indian customers with their profiles. Testimonials may be enhanced for tone, concision and relevance with an LLM tool.
- Online Application Form: A form where prospective customers can submit their details (Name, Loan Amount, Gender, State, Aadhar Card, PAN Card, Bank Passbook Photo, Personal Photo).
- Form Submission and Excel Export: Admin panel feature that allows viewing submitted application details and exporting data to an Excel sheet.
- Admin Panel Authentication: Password protected Admin Panel.

## Style Guidelines:

- Primary color: A deep sky blue (#007BFF) to convey trust and stability.
- Background color: A very light blue (#F0F8FF). The light tint is reminiscent of the primary while receding behind content.
- Accent color: A vivid blue-violet (#7019FE) to provide contrast with calls to action and highlight important information.
- Body font: 'PT Sans' (sans-serif) for a warm, modern, professional feel.
- Headline font: 'Playfair' (serif) for an elegant, fashionable, high-end feel.
- Use simple, professional icons related to finance and banking.
- Subtle transitions and animations for loading states and form submissions.